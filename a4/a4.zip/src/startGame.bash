set -e -x

java Game
