
./cleanup.bash
./build.bash
./startGame.bash
