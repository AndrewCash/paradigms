// Andrew Cash
// Programming Paradigms
// Fall 2018
// Assignment 4

import java.awt.Graphics;
import java.awt.Color;
import java.util.Random;

class Coin extends Sprite
{
    static Random rand = new Random();

    Coin(int _x, int _y)
    {
        x = _x;
        y = _y;
        w = 75;
        h = 75;

        // Generate random horizontal velocity
        double d = rand.nextDouble() * 16 - 8;
        horz_vel = d;
    }

    Coin(Json obj)
    {
        x = (int)obj.getLong("x");
        y = (int)obj.getLong("y");
    }

    void update()
    {
        y += vert_vel;
        x += horz_vel;
    }

    void draw(Graphics g, Model model, View view)
    {
        g.drawImage(view.coin, this.x - model.scrollPos, this.y, null);
    }
}

class CoinBlock extends Sprite
{
    int numCoinsReleased;

    CoinBlock(int _x, int _y)
    {
        x = _x;
        y = _y;
        w = 89;
        h = 83;
    }

    CoinBlock(Json obj)
    {
        x = (int)obj.getLong("x");
        y = (int)obj.getLong("y");
    }

    void update()
    {
        if (hittingBottom)
        {
            numCoinsReleased++;
            System.out.println("aaaaaaaaaaaaaaaaā");
            hittingBottom = false;
        }

    }

    void draw(Graphics g, Model model, View view)
    {
        if (numCoinsReleased < 5)
            g.drawImage(view.fullBlock, this.x - model.scrollPos, this.y, null);
        else
            g.drawImage(view.emptyBlock, this.x - model.scrollPos, this.y, null);
    }

    boolean am_I_a_CoinBlock()
    {
        return true;
    }


}
