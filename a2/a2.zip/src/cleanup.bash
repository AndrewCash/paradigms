#!/bin/bash

set -x
echo "Remove binary files"
rm *.class
